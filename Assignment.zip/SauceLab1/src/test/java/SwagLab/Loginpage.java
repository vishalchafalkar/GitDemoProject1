package SwagLab;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


   public class Loginpage {
    WebDriver driver;
    
    @BeforeMethod
	public void setUp()
	{
	System.setProperty("webDriver.chrome.driver", "C:\\Users\\vchafalk\\Downloads\\Drivers\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();
	
	}

       

        @Test 
        // 1.Login Page
        public void Login() throws InterruptedException {
    	driver.get("https://www.saucedemo.com/");
    	driver.manage().window().maximize();
    	driver.findElement(By.id("user-name")).sendKeys("standard_user");
    	driver.findElement(By.id("password")).sendKeys("secret_sauce");
    	driver.findElement(By.id("login-button")).click();
    	
  
         // 2. Filter the item price low to high
        driver.findElement(By.xpath("//*[@class='product_sort_container']")).click();
        driver.findElement(By.xpath("//*[text()='Price (low to high)']")).click();
     
        Thread.sleep(3000);
    
    
    
        // 3. Add the items to the cart
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-onesie\"]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='add-to-cart-sauce-labs-bike-light']")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='add-to-cart-sauce-labs-bolt-t-shirt']")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='add-to-cart-test.allthethings()-t-shirt-(red)']")).click();
    
    
        Thread.sleep(4000);
    
       // 4. Verify the number of items in the cart
       driver.findElement(By.xpath("//*[@class='shopping_cart_link']")).click();
       int cart_quantity = driver.findElements(By.xpath("//*[text()='Remove']")).size();    
       System.out.println("Number of items in the cart = "+" " + cart_quantity);
    
       Thread.sleep(4000);
    
    
       // 5. Remove some of the items from the cart
       driver.findElement(By.xpath("//*[@id='remove-sauce-labs-onesie']")).click();
       Thread.sleep(2000);
       driver.findElement(By.xpath("//*[@id='remove-sauce-labs-bike-light']")).click();
    
       Thread.sleep(4000);
    
       // 6. Click on Continue shopping button and add some more items to the cart
      driver.findElement(By.xpath("//*[@id='continue-shopping']")).click(); // Click on continue button
      driver.findElement(By.xpath("//*[@id='add-to-cart-sauce-labs-bike-light']")).click();
      Thread.sleep(2000);
      driver.findElement(By.xpath("//*[@id='add-to-cart-sauce-labs-fleece-jacket']")).click();
      Thread.sleep(2000);
      driver.findElement(By.xpath("//*[@id='add-to-cart-sauce-labs-onesie']")).click();
    
      Thread.sleep(4000);
    
    
      // 7. Verify the number of items in the cart
     driver.findElement(By.xpath("//*[@class='shopping_cart_link']")).click();
     int items = driver.findElements(By.xpath("//*[text()='Remove']")).size();    
     System.out.println("Number of items in the cart = "+" " + items);
    
     Thread.sleep(4000);
    
     // 8. Perform check out
     driver.findElement(By.xpath("//*[@id='checkout']")).click();

    
     //9.Validate item cost is matched with total amount
     
     driver.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys("Vishal");
     driver.findElement(By.xpath("//*[@id=\"last-name\"]")).sendKeys("Chafalkar");
     driver.findElement(By.xpath("//*[@id=\"postal-code\"]")).sendKeys("414001");
     Thread.sleep(2000);
     driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
     
     
     // 10.logout
     driver.findElement(By.xpath("//*[@id='finish']")).click();
     Thread.sleep(2000);
     driver.findElement(By.xpath("//*[@id='react-burger-menu-btn']")).click();
     Thread.sleep(2000);
     driver.findElement(By.xpath("//*[@id='logout_sidebar_link']")).click();
     driver.close();

  }
    
    
}  
