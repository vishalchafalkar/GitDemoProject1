package org.testrunner.com;
//Method 1 - Runner by TestNG


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src//test//resources//Login", glue = {
		"org.login.com" }, monochrome = false, plugin = { "pretty", "html:target/HTMLReports",
				"json:target/JsonReports/JsonReport.json", "junit:target/JunitReports/JunitReport.xml" })

public class runner extends AbstractTestNGCucumberTests {

}

//Method 2 - Runner by JUnit
//import org.junit.runner.RunWith;
//
//import io.cucumber.junit.Cucumber;
//import io.cucumber.junit.CucumberOptions;
//
//@RunWith(Cucumber.class)
//@CucumberOptions(features = "src//test//resources//Login", glue = { "org.login.com" }, plugin = { "pretty",
//		"html:target/HTMLReports", "json:target/JsonReports/JsonReport.json",
//		"junit:target/JunitReports/JunitReport.xml" })
//public class runner {
//
//}


//import io.cucumber.testng.AbstractTestNGCucumberTests;
//import io.cucumber.testng.CucumberOptions;

//@CucumberOptions()
//public class runner extends AbstractTestNGCucumberTests {
//}
