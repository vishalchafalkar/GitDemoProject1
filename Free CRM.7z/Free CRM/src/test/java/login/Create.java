package login;

import org.browser.com.browser;
import org.pages.com.CompanyPage;
import org.pages.com.HomePage;
import org.pages.com.Loginpage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Create extends browser{
	@Given("User opens any browser")
	public void user_opens_any_browser() {
		// Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		browser.setDriver();
	}

	@When("User enters the website {string}")
	public void user_enters_the_website(String string) throws Exception {
		// Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		browser.getUrl();
	}

	@And("User enter {string} Email-Address")
	public void user_enter_Email_Address(String string) throws Exception {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		Loginpage.inputCredentials();
	}
	
	@And("User enter {string} Password")
	public void user_enter_Password(String string) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		//Loginpage.inputCredentials();
	}

	@Then("User presses Login button")
	public void user_presses_Login_button() throws Exception {
		// Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		Loginpage.clickOnLoginButton();
	}
	
	@And("User navigated to {string} page")
	public void user_navigated_to_page(String string) {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		HomePage.moveToElement(string);
	}
	
	@When("User clicks on Create button")
	public void user_clicks_on_Create_button() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    CompanyPage.createbutton();
	}

	@And("User enters {string} title for company")
	public void user_enters_title_for_company(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    CompanyPage.inputNewTitle();
	}

	@And("User enters {string} number of employees")
	public void user_enters_number_of_employees(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		CompanyPage.inputNumofEmp();
	}

	@And("User clicks on Save button")
	public void user_clicks_on_Save_button() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		CompanyPage.saveButton();
	}

	@And("User clicks on Read Icon for {string}company")
	public void user_clicks_on_Read_Icon(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		CompanyPage.ReadIcon(string);
	}

	@And("User clicks on Edit Icon for {string} updated details.")
	public void user_clicks_on_Edit_Icon(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    // throw new io.cucumber.java.PendingException();
		CompanyPage.EditIcon(string);
	}

	@Then("User enters {string} in Name Textbox.")
	public void user_enters_in_Name_Textbox(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    // throw new io.cucumber.java.PendingException();
		CompanyPage.updateNumofEmp();
	}

	@And("Clicks on Save button.")
	public void clicks_on_Save_button() {
	    // Write code here that turns the phrase above into concrete actions
	    // throw new io.cucumber.java.PendingException();
	    CompanyPage.saveButton();
	}

	@And("User clicks on Delete Icon")
	public void user_clicks_on_Delete_Icon() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		CompanyPage.deleteButton();
	}

	@Then("User clicks on Delete button in pop-up box")
	public void user_clicks_on_Delete_button_in_pop_up_box() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		CompanyPage.deleteButtonpopup();
	}
}
