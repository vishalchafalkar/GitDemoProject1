package login;

import java.io.IOException;

import org.browser.com.browser;
import org.pages.com.CompanyPage;
import org.pages.com.HomePage;
import org.pages.com.Loginpage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login extends browser {
	@Given("User opens the browser")
	public void user_opens_the_browser() {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		browser.setDriver();
	}

	@When("User enters the url {string}")
	public void user_enters_the_url(String string) throws Exception {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		browser.getUrl();
	}

	@And("User enters {string} Email-Address")
	public void user_enters_Email_Address(String string) throws Exception {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		Loginpage.inputCredentials();
	}

	@And("User enters {string} Password")
	public void user_enters_Password(String string) {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		System.out.println("User enters password method");
	}

	@Then("User pressed Login button")
	public void user_pressed_Login_button() throws Exception {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		Loginpage.clickOnLoginButton();
	}

	@And("User navigated to {string} page for module")
	public void user_navigated_to_page_for_module(String string) {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		HomePage.moveToElement(string);
	}

	@And("Verified whether page is displayed or not")
	public void verified_whether_page_is_displayed_or_not() {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		HomePage.verifyurl();
	}

	@Then("closed the browser.")
	public void closed_the_browser() {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		// browser.closeBrowser();
		System.out.println("Closing Browser method present");
	}

	@And("User clicks on Export button.")
	public void user_clicks_on_Export_button() {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		CompanyPage.exportButton();
	}

	@Then("User clicks on OK button in pop-up box.")
	public void user_clicks_on_OK_button_in_pop_up_box() {
		// Write code here that turns the phrase above into concrete actions
		// throw new io.cucumber.java.PendingException();
		CompanyPage.exportButtonpopup();
	}
}
