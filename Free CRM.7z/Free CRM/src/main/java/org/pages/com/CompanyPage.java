package org.pages.com;

import java.util.List;

import org.browser.com.browser;
import org.excel.com.Read;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.report.com.report;
import org.screenshot.com.ScreenCapture;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class CompanyPage extends browser {

	public static void createbutton() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Creating new company record");
		logger.log(Status.INFO, "Creating new company record");
		try {
			report.sample(1);
			String createButtonPath = browser.fileProperties("createButton");
			WebElement clickButton = driver.findElement(By.xpath(createButtonPath));
			clickButton.click();
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("created new company record");
			logger.log(Status.PASS, "created new company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT creating new company record");
			logger.log(Status.FAIL, "NOT creating new company record");
		}
	}

	public static void inputNewTitle() {
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Entering title for new company record");
		logger.log(Status.INFO, "Entering tile for Creating new company record");
		try {
			report.sample(1);
			String title = Read.readExcel(2, 1);
			String titlePath = browser.fileProperties("name");
			WebElement inputTitle = driver.findElement(By.name(titlePath));
			inputTitle.sendKeys(title);
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("entered title for new company record");
			logger.log(Status.PASS, "entered title for new company record");
			ScreenCapture.screenShot(2);
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT entering title for new company record");
			logger.log(Status.FAIL, "NOT entering title for new company record");
		}
	}

	public static void inputNumofEmp() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Entering Num. Of Employees for new company record");
		logger.log(Status.INFO, "Entering Num. Of Employees for Creating new company record");
		try {
			report.sample(1);
			String Num_Of_Employees = Read.readExcel(3, 1);
			String Num_of_EmployeesPath = browser.fileProperties("Num_of_Employees");
			WebElement inputNum_of_Employees = driver.findElement(By.name(Num_of_EmployeesPath));
			inputNum_of_Employees.sendKeys(Num_Of_Employees);
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("entered Num. Of Employees for new company record");
			logger.log(Status.PASS, "entered Num. Of Employees for new company record");
			ScreenCapture.screenShot(3);
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT entering Num. Of Employees for new company record");
			logger.log(Status.FAIL, "NOT entering Num. Of Employees for new company record");
		}
	}

	public static void saveButton() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Clicking on Save button for new company record");
		logger.log(Status.INFO, "Clicking on Save button for Creating new company record");
		try {
			report.sample(1);
			String saveButtonPath = browser.fileProperties("saveButton");
			WebElement saveButton = driver.findElement(By.xpath(saveButtonPath));
			saveButton.click();
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("Clicked on Save button for new company record");
			logger.log(Status.PASS, "Clicked on Save button for new company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT Clicked on Save button for new company record");
			logger.log(Status.FAIL, "NOT Clicked on Save button for new company record");
		}
	}

	public static void deleteButton() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Clicking on delete button for deleting company record");
		logger.log(Status.INFO, "Clicking on delete button for deleting company record");
		try {
			report.sample(1);
			String deleteButtonPath = browser.fileProperties("deleteButton");
			WebElement deleteButton = driver.findElement(By.xpath(deleteButtonPath));
			deleteButton.click();
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("Clicked on delete button for deleting company record");
			logger.log(Status.PASS, "Clicked on delete button for deleting company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT Clicking on delete button for deleting company record");
			logger.log(Status.FAIL, "NOT Clicking on delete button for deleting company record");
		}
	}

	public static void deleteButtonpopup() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Clicking on delete button in pop-up for deleting company record");
		logger.log(Status.INFO, "Clicking on delete button in pop-up for deleting company record");
		try {
			report.sample(1);
			String deletepopupButtonPath = browser.fileProperties("deletepopupButton");
			WebElement deletepopupButton = driver.findElement(By.xpath(deletepopupButtonPath));
			deletepopupButton.click();
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("Clicked on delete button in pop-up for deleting company record");
			logger.log(Status.PASS, "Clicked on delete button in pop-up for deleting company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT Clicking on delete button in pop-up for deleting company record");
			logger.log(Status.FAIL, "NOT Clicking on delete button in pop-up for deleting company record");
		}
	}

	public static void updateNumofEmp() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Updating Num. Of Employees for new company record");
		logger.log(Status.INFO, "Updating Num. Of Employees for Creating new company record");
		try {
			String newNo_of_Employees = Read.readExcel(4, 1);
			report.sample(1);
			String Num_of_EmployeesPath = browser.fileProperties("Num_of_Employees");
			WebElement inputNum_of_Employees = driver.findElement(By.name(Num_of_EmployeesPath));
			inputNum_of_Employees.sendKeys(newNo_of_Employees);
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("Updated Num. Of Employees for new company record");
			logger.log(Status.PASS, "Updated Num. Of Employees for new company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT Updating Num. Of Employees for new company record");
			logger.log(Status.FAIL, "NOT Updating Num. Of Employees for new company record");
		}
	}

	public static void exportButton() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Clicking on export button for exporting company record");
		logger.log(Status.INFO, "Clicking on export button for exporting company record");
		try {
			report.sample(1);
			String exportButtonPath = browser.fileProperties("exportButton");
			WebElement exportButton = driver.findElement(By.xpath(exportButtonPath));
			exportButton.click();
			Thread.sleep(4000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("Clicked on export button for expoting company record");
			logger.log(Status.PASS, "Clicked on export button for exporting company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT Clicking on export button for exporting company record");
			logger.log(Status.FAIL, "NOT Clicking on export button for exporting company record");
		}
	}

	public static void exportButtonpopup() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Clicking on Export button in pop-up for exporting company record");
		logger.log(Status.INFO, "Clicking on Export button in pop-up for exporting company record");
		try {
			report.sample(1);
			String exportpopupButtonPath = browser.fileProperties("exportpopupButton");
			WebElement exportpopupButton = driver.findElement(By.xpath(exportpopupButtonPath));
			exportpopupButton.click();
			Thread.sleep(4000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("Clicked on export button in pop-up for exporting company record");
			logger.log(Status.PASS, "Clicked on export button in pop-up for exporting company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT Clicking on export button in pop-up for exporting company record");
			logger.log(Status.FAIL, "NOT Clicking on export button in pop-up for exporting company record");
		}
	}

	public static void ReadIcon(String string) {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Reading company record");
		logger.log(Status.INFO, "Reading company record");
		try {
			report.sample(1);
			String createButtonPath = browser.fileProperties("readIcon");
			List<WebElement> clickButton = driver.findElements(By.xpath(createButtonPath));
			int count = 0;
			int s=Integer.parseInt(string);
			for (int i = 0; i < clickButton.size(); i++)
			{
				count++;
				if (i % 2 == 0 && count==s ) {
					clickButton.get(i).click();
					break;
				}
			}
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("Done Reading company record");
			logger.log(Status.PASS, "Done reading company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT creating new company record");
			logger.log(Status.FAIL, "NOT creating new company record");
		}
	}

	public static void EditIcon(String string) {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Reading company record");
		logger.log(Status.INFO, "Reading company record");
		try {
			report.sample(1);
			String createButtonPath = browser.fileProperties("readIcon");
			List<WebElement> clickButton = driver.findElements(By.xpath(createButtonPath));
			int count = 0;
			int s=Integer.parseInt(string);
			for (int i = 0; i < clickButton.size(); i++)
			{
				count++;
				if (i % 2 == 1 && count==s ) {
					clickButton.get(i).click();
					break;
				}
			}
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			System.out.println("Done Reading company record");
			logger.log(Status.PASS, "Done reading company record");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT creating new company record");
			logger.log(Status.FAIL, "NOT creating new company record");
		}
	}
}
