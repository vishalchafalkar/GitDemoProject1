package org.pages.com;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.browser.com.browser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.report.com.report;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class HomePage extends browser {
	public static void moveToElement(String string) {
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Navigating to companies in browser");
		logger.log(Status.INFO, "Navigating to companies in browser");
		try {
			report.sample(1);
			Thread.sleep(4000);
			// driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			Actions action = new Actions(driver);
//			String filePath3 = browser.fileProperties("key");
//			List<WebElement> moduleData = driver.findElements(By.xpath(filePath3));
//			System.out.println(moduleData.size());
//			for (WebElement e : moduleData) {
//				if (e.getText().toLowerCase().equals(string)) {
//					action.moveToElement(e).build().perform();
//					// driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
//					Thread.sleep(4000);
//					e.click();
//				}
//			}
			action.moveToElement(driver.findElement(By.xpath(browser.fileProperties("key")))).build().perform();
			driver.findElement(By.xpath(browser.fileProperties("key"))).click();
			System.out.println("Navigated to companies in browser");
			logger.log(Status.PASS, "Navigated to companies in browser");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT Navigating to companies in browser");
			logger.log(Status.FAIL, "NOT Navigating to companies in browser");
		}
	}

	public static void verifyurl() {
		// TODO Auto-generated method stub
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Verifying companies URL in browser");
		logger.log(Status.INFO, "Verifying companies URL in browser");
		String actualResult = driver.getCurrentUrl();
		String expectedResult = "https://ui.freecrm.com/companies";
		try {
			report.sample(1);
			Assert.assertTrue((expectedResult.equals(actualResult)) ? true : false);
			// (Condition) ? True : false
			System.out.println("Verifyied companies URL in browser");
			logger.log(Status.PASS, "Verified companies URL in browser");
		} catch (AssertionError e) {
			report.sample(3);
			System.out.println("NOT Verifying companies URL in browser");
			logger.log(Status.FAIL, "NOT Verifying companies URL in browser");
		}
	}
}
