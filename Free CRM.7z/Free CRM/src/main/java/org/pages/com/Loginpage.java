package org.pages.com;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.browser.com.browser;
import org.excel.com.Read;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.report.com.report;
import org.screenshot.com.ScreenCapture;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Loginpage extends browser {
	public static ExtentHtmlReporter htmlreporter = new ExtentHtmlReporter("./ExtentReport/ExtentReport1.html");
	public static ExtentReports extent = new ExtentReports();

	public static void inputCredentials() throws Exception {
		try {
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			String userName = Read.readExcel(0, 1);
			String filePath = browser.fileProperties("username");
			WebElement inputUsername = driver.findElement(By.name(filePath));
			inputUsername.sendKeys(userName);
			Thread.sleep(2000);
			// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			String passWord = Read.readExcel(1, 1);
			String filePath1 = browser.fileProperties("password");
			WebElement inputPassword = driver.findElement(By.name(filePath1));
			inputPassword.sendKeys(passWord);
			ScreenCapture.screenShot(1);
		} catch (NullPointerException e) {
			System.out.println("Input UserName and Password Data");
		}
	}

	public static void clickOnLoginButton() throws Exception {
		try {
			String filePath2 = browser.fileProperties("presskey");
			WebElement clickButton = driver.findElement(By.xpath(filePath2));
			clickButton.click();
		} catch (Exception e) {
			System.out.println("Click on Login Button");
		}
	}

	public static void verifycorrectpage() {
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Verifying for Correct Page ");
		logger.log(Status.INFO, "Verifying for Correct Page ");
		String actualResult = driver.getTitle();
		String expectedResult = "Cogmento CRM";
		try {
			report.sample(1);
			if (actualResult == expectedResult) {
				System.out.println("Correct Page is Displayed");
			}
			logger.log(Status.PASS, "Verified for Correct Page ");

		} catch (Exception e) {
			report.sample(3);
			System.out.println("CAtch in Verifying CRM Page is displayed or not");
			logger.log(Status.FAIL, "Not Verifying for Correct Page ");
		}
	}
}
