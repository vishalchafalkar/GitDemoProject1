package org.browser.com;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.report.com.report;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class browser {
	public static WebDriver driver;
	public static Actions act;
	public static WebDriverWait wait;
	public static ExtentHtmlReporter htmlreporter = new ExtentHtmlReporter("./ExtentReport/ExtentReport1.html");
	public static ExtentReports extent = new ExtentReports();
	// static ReadProperties obj = new
	// ReadProperties("./src/main/resources/ApplicationProperty/Configuration.properties");

	public static String fileProperties(String propertiesData) throws FileNotFoundException {
		String returnData = null;
		String searchData = propertiesData;
		try {
			String filepath = System.getProperty("user.dir")
					+ "//src/main/resources/ApplicationProperty/Configuration.Properties";
			FileInputStream objFile = new FileInputStream(filepath);
			Properties obj = new Properties();
			obj.load(objFile);
			returnData = obj.getProperty(searchData);
			// System.out.println(returnData);
		} catch (Exception e) {
			System.out.println("Properties");
		}

		return returnData;
	}

	public static WebDriver setDriver() {
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Setting Driver for browser");
		logger.log(Status.INFO, "Setting Driver for browser");
		try {
			report.sample(1);
			String browserChoice = browser.fileProperties("browser");// chrome
			System.out.println(browserChoice);

			// String browserChoice = Browser.fileProperties("browser");
			if (browserChoice.equals("chrome")) {
				driver = setChromeDriver();
			} else if (browserChoice.equals("firefox")) {
				driver = setFirefoxDriver();
			} else if (browserChoice == "edge") {
				driver = setEdgeDriver();
			} else {
				System.out.println("Invalid data...");
			}
			act = new Actions(driver);
			logger.log(Status.PASS, "Driver Setup done for browser");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("Browser Input");
			System.out.println(e);
			logger.log(Status.FAIL, "Driver Setup failed for browser");
		}
		return driver;
	}

	/*
	 * ChromeDriver Setup Method
	 */
	public static WebDriver setChromeDriver() {
		try {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} catch (Exception e) {
			System.out.println("Chrome");
			System.out.println(e);
		}
		return driver;
	}

	// Internet Explorer Driver Setup Method
	public static WebDriver setFirefoxDriver() {
		try {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} catch (Exception e) {
			System.out.println("Firefox");
			System.out.println(e);
		}
		return driver;
	}

	// Microsoft Edge Driver Setup Method
	public static WebDriver setEdgeDriver() {
		try {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		} catch (Exception e) {
			System.out.println("Edge");
			System.out.println(e);
		}
		return driver;
	}

	// Url Setup Method
	public static void getUrl() throws Exception {
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Getting URL from browser");
		logger.log(Status.INFO, "Getting URL from browser");
		try {
			report.sample(1);
			String url = browser.fileProperties("url");
			driver.get(url);
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			logger.log(Status.PASS, "got URL in browser");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("NOT getting URL in browser");
			logger.log(Status.FAIL, "NOT getting URL in browser");
		}
	}

	// Method to get title of the browser window
	public static String getTitle() throws Exception {
		String actualTitle = driver.getTitle();
		return actualTitle;
	}

	// Driver Close Method
	public static void closeBrowser() {
		report.sample(2);
		extent.attachReporter(htmlreporter);
		ExtentTest logger = extent.createTest("Closing browser");
		logger.log(Status.INFO, "Closing browser");
		try {
			report.sample(1);
			driver.quit();
			logger.log(Status.PASS, "closed browser");
		} catch (Exception e) {
			report.sample(3);
			System.out.println("closing browser");
			logger.log(Status.FAIL, "NOT closing browser");
		}
	}
}
